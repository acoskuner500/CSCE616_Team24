1662518097 /home/grads/a/acoskuner500/csce_616_fall_22/lab1_simple_mem_tb/lab1/mem_design_tb/design/simple_mem.sv
1662517727 /home/grads/a/acoskuner500/csce_616_fall_22/lab1_simple_mem_tb/lab1/mem_design_tb/tb/simple_mem_tb.sv
